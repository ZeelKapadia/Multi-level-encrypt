var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var debug = require('debug');

var indexRouter = require('./routes/index');
//!
var databaselevelencryptionRouter = require('./routes/database-level-encryption/index');
//!
var userlevelencryptionRouter = require('./routes/user-level-encryption/index');

var app = express();

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());

app.use('/', indexRouter);
app.use('/databaselevelencryption', databaselevelencryptionRouter);
app.use('/userlevelencryption', userlevelencryptionRouter);


app.set('port', process.env.PORT || 3000);

var server = app.listen(app.get('port'), function () {
    debug('Express server listening on port ' + server.address().port);
});
