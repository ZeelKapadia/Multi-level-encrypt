const jwt = require('jsonwebtoken');

const method = {};

method.createCipherJWT = (text) => {
    try {
        const token = jwt.sign(text, "dRl3%c1^2X0I0Z1OrpwOeeuFv0ep9@");
        return {
            flag: true, crypto: token
        };

    } catch (error) {
        return {
            flag: false
        };
    }
};

method.createDecipherJWT = (text) => {
    try {
        const verified = jwt.verify(text, "dRl3%c1^2X0I0Z1OrpwOeeuFv0ep9@");
        if (verified)
            return {
                flag: true, crypto: verified
            };
        else
            return {
                flag: false
            };

    } catch (error) {
        return {
            flag: false
        };
    }
};

module.exports = method;