let crypto = require("crypto");
const jwt = require('jsonwebtoken');

const method = {};

method.createCipher = (text) => {
    try {
        var crypto = require("crypto");
        var mykey = crypto.createCipher("aes-128-cbc", "dRl3%c1^2X0I0Z1OrpwOeeuFv0ep9@");
        var mystr = mykey.update(text, "utf8", "hex");
        mystr += mykey.final("hex");

        return {
            flag: true, crypto: mystr
        };

    } catch (error) {
        return {
            flag: false
        };
    }
};

method.createDecipher = (text) => {
    try {
        var crypto = require('crypto');
        var mykey = crypto.createDecipher('aes-128-cbc', 'dRl3%c1^2X0I0Z1OrpwOeeuFv0ep9@');
        var mystr = mykey.update(text, 'hex', 'utf8')
        mystr += mykey.final('utf8');

        return {
            flag: true, crypto: mystr
        };

    } catch (error) {
        return {
            flag: false
        };
    }
};

method.createCipherJWT = (text) => {
    try {
        const token = jwt.sign(text, "dRl3%c1^2X0I0Z1OrpwOeeuFv0ep9@");
        return {
            flag: true, crypto: token
        };

    } catch (error) {
        return {
            flag: false
        };
    }
};

method.createDecipherJWT = (text) => {
    try {
        const verified = jwt.verify(text, "dRl3%c1^2X0I0Z1OrpwOeeuFv0ep9@");
        if (verified)
            return {
                flag: true, crypto: verified
            };
        else
            return {
                flag: false
            };

    } catch (error) {
        return {
            flag: false
        };
    }
};

method.createMultiLevelCipher = (text, key) => {
    try {
        // Level 1
        const token = jwt.sign(text, "dRl3%c1^2X0I0Z1OrpwOeeuFv0ep9@");
        // Level 2
        var crypto = require("crypto");
        var mykey = crypto.createCipher("aes-128-cbc", key);
        var mystr = mykey.update(token, "utf8", "hex");
        mystr += mykey.final("hex");

        return {
            flag: true, crypto: mystr
        };

    } catch (error) {
        return {
            flag: false
        };
    }
};

method.createMultiLevelDecipher = (text, key) => {
    try {
        // Level 2 
        var crypto = require('crypto');
        var mykey = crypto.createDecipher('aes-128-cbc', key);
        var mystr = mykey.update(text, 'hex', 'utf8')
        mystr += mykey.final('utf8');
        // Level 1
        const verified = jwt.verify(mystr, "dRl3%c1^2X0I0Z1OrpwOeeuFv0ep9@");

        if (verified)
            return {
                flag: true, crypto: verified
            };
        else
            return {
                flag: false
            };

    } catch (error) {
        return {
            flag: false
        };
    }
};

module.exports = method;