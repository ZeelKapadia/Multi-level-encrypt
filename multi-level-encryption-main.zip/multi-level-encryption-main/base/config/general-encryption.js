let crypto = require("crypto");

const method = {};

method.createCipher = (text) => {
    try {
        var crypto = require("crypto");
        var mykey = crypto.createCipher("aes-128-cbc", "dRl3%c1^2X0I0Z1OrpwOeeuFv0ep9@");
        var mystr = mykey.update(text, "utf8", "hex");
        mystr += mykey.final("hex");

        return {
            flag: true, crypto: mystr
        };

    } catch (error) {
        return {
            flag: false
        };
    }
};

method.createDecipher = (text) => {
    try {
        var crypto = require('crypto');
        var mykey = crypto.createDecipher('aes-128-cbc', 'dRl3%c1^2X0I0Z1OrpwOeeuFv0ep9@');
        var mystr = mykey.update(text, 'hex', 'utf8')
        mystr += mykey.final('utf8');

        return {
            flag: true, crypto: mystr
        };

    } catch (error) {
        return {
            flag: false
        };
    }
};

module.exports = method;