var express = require('express');
var router = express.Router();

let cipher = require("../../base/config/general-encryption");
let cipherJWT = require("../../base/config/jwt-encryption");
let multilevelEncryption = require("../../base/config/multi-level-encryption");

/* GET home page. */
router.post('/createcipher', function (req, res, next) {

    try {
        let userName = req.body.userName;
        let createCipherText = cipher.createCipher(userName);

        res.send({
            "userName": createCipherText
        })

    } catch (error) {

    }
});

router.post('/createdecipher', function (req, res, next) {

    try {
        let userName = req.body.userName;
        let createDecipherText = cipher.createDecipher(userName);

        res.send({
            "userName": createDecipherText.crypto
        })

    } catch (error) {

    }
});

router.post('/createcipherJWT', function (req, res, next) {

    try {
        let userName = req.body.userName;
        let createCipherText = cipherJWT.createCipherJWT(userName);

        res.send({
            "userName": createCipherText
        })

    } catch (error) {

    }
});

router.post('/createdecipherJWT', function (req, res, next) {

    try {
        let userName = req.body.userName;
        let createDecipherText = cipherJWT.createDecipherJWT(userName);

        res.send({
            "userName": createDecipherText.crypto
        })

    } catch (error) {

    }
});

router.post('/createciphertwolevel', function (req, res, next) {

    try {
        let curretTime = new Date().getMilliseconds().toString();
        let userName = req.body.userName;
        let createCipherText = multilevelEncryption.createMultiLevelCipher(userName, curretTime);

        res.send({
            "currentTime": curretTime,
            "userName": createCipherText
        })

    } catch (error) {

    }
});

router.post('/createdeciphertwolevel', function (req, res, next) {

    try {

        let key = req.headers["time"];
        console.log(key);
        let userName = req.body.userName;
        let createCipherText = multilevelEncryption.createMultiLevelDecipher(userName, key);

        res.send({
            "userName": createCipherText
        })

    } catch (error) {

    }
});

module.exports = router;
