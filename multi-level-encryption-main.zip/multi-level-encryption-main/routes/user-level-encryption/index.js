var express = require('express');
var router = express.Router();

let cipher = require("../../base/config/jwt-encryption")

/* GET home page. */
router.post('/createcipher', function (req, res, next) {

    try {
        let userName = req.body.userName;
        let createCipherText = cipher.createCipher(userName);

        res.send({
            "userName": createCipherText
        })

    } catch (error) {

    }
});

router.post('/createdecipher', function (req, res, next) {

    try {
        let userName = req.body.userName;
        let createDecipherText = cipher.createDecipher(userName);

        res.send({
            "userName": createDecipherText.crypto
        })

    } catch (error) {

    }
});

module.exports = router;
